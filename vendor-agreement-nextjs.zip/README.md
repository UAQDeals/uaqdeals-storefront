# Vendor Agreement Generator — Next.js page (App Router)

Public page at `/vendor-agreement` (no login, not indexed by search engines).

## Install
1. Copy `app/vendor-agreement/` into the storefront's `app/` folder (or `src/app/` if the project uses `src`).
2. Copy `public/vendor-agreement/` into the storefront's `public/` folder.
3. No npm install needed (pdfmake is bundled in `public/vendor-agreement/`).
4. Build and deploy. URL: https://uaqdeals.ae/vendor-agreement

To change the URL, rename the `app/vendor-agreement` folder. Keep `public/vendor-agreement` as is (fonts + logo are loaded from there).

## Files
- `page.tsx` — route + metadata (noindex)
- `VendorAgreementForm.tsx` — the form and Generate PDF button (client component)
- `fields.ts` — field list, example data, defaults
- `buildDoc.ts` — the agreement text and PDF layout; UAQ Deals' own details are in the `UAQ` object at the top
- `vendor-agreement.css` — styles, all scoped under `.va-page`
